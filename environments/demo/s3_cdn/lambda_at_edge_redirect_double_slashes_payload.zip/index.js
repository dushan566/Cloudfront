'use strict';
exports.handler = (event, context, callback) => {

    // Get request from CloudFront event
    var request = event.Records[0].cf.request;

    // Extract the URI from the request
    var requestUrl = request.uri;

    // Match url ending with '//' and remove in any place
    var redirectUrl = requestUrl.replace(/([^:]\/)\/+/g, "$1");

    // Replace the received URI with the URI that includes the index page
    request.uri = redirectUrl;

    // Return to CloudFront
    return callback(null, request);
};
